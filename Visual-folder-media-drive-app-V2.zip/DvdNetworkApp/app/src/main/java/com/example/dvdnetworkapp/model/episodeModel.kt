package com.example.dvdnetworkapp.model

data class episodeModel(val episode: String)

